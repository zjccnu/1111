package com.example.administrator.homework1.pro.base.view;

import com.example.administrator.homework1.mvp.presenter.impl.MvpBasePresent;
import com.example.administrator.homework1.mvp.view.impl.MvpActivity;

/**
 * Created by Administrator on 2016/5/27.
 */
public abstract class BaseActivity<P extends MvpBasePresent> extends MvpActivity<P>{
}
