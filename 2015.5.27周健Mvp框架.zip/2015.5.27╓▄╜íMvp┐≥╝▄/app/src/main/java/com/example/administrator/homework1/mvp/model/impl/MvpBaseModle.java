package com.example.administrator.homework1.mvp.model.impl;

import com.example.administrator.homework1.mvp.model.MvpModel;

/**
 * Created by Administrator on 2016/5/27.
 */
public class MvpBaseModle implements MvpModel {
}
