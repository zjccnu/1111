package com.example.administrator.news;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/5/26.
 */
public class NewsTitleFragment extends android.support.v4.app.Fragment implements AdapterView.OnItemClickListener {
    private ListView newsTitleListView;
    private List<New> newslist;
    private  NewsAdapter adapter;
    String TAG1="11";
    String TAG2="22";
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        newslist=getNews();
        adapter=new NewsAdapter(context,R.layout.new_item,newslist);
        Log.i("11", "onAttach: ");
    }

  public  View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
      View view=inflater.inflate(R.layout.news_title_frag,container,false);
      newsTitleListView=(ListView)view.findViewById(R.id.news_title_list_view);
      newsTitleListView.setAdapter(adapter);
      newsTitleListView.setOnItemClickListener(this);
     Log.i("11", "onCreateView ");
      return  view;
  }
public void onActivityCreated(Bundle savedInstanceState){
    super.onActivityCreated(savedInstanceState);
}
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        New news=newslist.get(position);
       NewsContentActivity.actionStart(getActivity(), news.getTitle(), news.getContent());

    }
    private List<New> getNews(){
        List<New> newsList1=new ArrayList<New>();
        New news1=new New();
        news1.setTitle("Succeed inConnleg");
        news1.setContent("sfdsfsahfhsdlfslkad");
        newslist.add(news1);
        New news2=new New();
        news2.setTitle("Succeed inConnleg");
        news2.setContent("sfdsfsahfhsdlfslkad");
        newslist.add(news2);
        return newsList1;
    }
}
