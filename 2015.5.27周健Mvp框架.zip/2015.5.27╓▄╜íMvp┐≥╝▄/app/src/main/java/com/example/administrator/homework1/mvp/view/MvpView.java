package com.example.administrator.homework1.mvp.view;

/**
 * Created by Administrator on 2016/5/27.
 */
public interface MvpView {
}
