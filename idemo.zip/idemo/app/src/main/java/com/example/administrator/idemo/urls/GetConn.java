package com.example.administrator.idemo.urls;
import android.content.Context;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
/**
 *
 * Created by Administrator on 2016/8/20.
 *
 */
public class GetConn {
    String  httpurl;
    URL url;
    String bf;
    Context mcontext;
    InputStream inputStream;
    Map<String,String> map;
    StringBuilder stringBuilder;
    public GetConn(String httpurl,Context context,Map<String,String> map){
         this.httpurl=httpurl;
         mcontext=context;
         this.map=map;
    }

  public void  DoGet() {
        try {
            //URL进行交互
            stringBuilder=new StringBuilder(httpurl);
            stringBuilder.append("?");
            for (String key:map.keySet()
                    ) {
                stringBuilder.append(key+"="+map.get(key)+"&");
            }
             stringBuilder.deleteCharAt(stringBuilder.length()-1);
             httpurl=stringBuilder.toString();
             url=new URL(httpurl);
            Log.d("aaaaa",httpurl);
             HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
            if(httpURLConnection.getResponseCode()==HttpURLConnection.HTTP_OK){
                inputStream=httpURLConnection.getInputStream();
                BufferedReader bufferread=new BufferedReader(new InputStreamReader(inputStream));
                bf=bufferread.readLine();
                //不懂这里为什么不能toast
               mt("成功");
            }
            else{
                mt("失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//post请求的请求思路:只不过后面的参数不能通过URL进行传递，用输出流传给服务器，其他方式基本上一样。
    public void  DoPost() {
        byte[] bytes;
        try {
            //URL进行交互
            url=new URL(httpurl);
            stringBuilder=new StringBuilder();

            for (String key:map.keySet()
                    ) {
                stringBuilder.append(key+"="+map.get(key)+"&");
            }
            stringBuilder.deleteCharAt(stringBuilder.length()-1);
            httpurl=stringBuilder.toString();
            bytes=httpurl.getBytes();
            Log.d("地址",httpurl);
            HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            OutputStream outputStream= httpURLConnection.getOutputStream();
            outputStream.write(bytes,0,bytes.length);
            outputStream.close();
            if(httpURLConnection.getResponseCode()==HttpURLConnection.HTTP_OK){
                inputStream=httpURLConnection.getInputStream();
                BufferedReader bufferread=new BufferedReader(new InputStreamReader(inputStream));
                bf=bufferread.readLine();
                //不懂这里为什么不能toast,子线程要开启一个消息队列才能Toast
               //   mt("成功");
                Log.d("返回的数据为",bf+"1111");
            }
            else{
                mt("失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
public void mt(String mess) {
  //非UI线程Toast需要加上这2句话
      Looper.prepare();
      Toast.makeText(mcontext,mess,Toast.LENGTH_LONG).show();
      Looper.loop();
  }
}
