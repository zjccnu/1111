package com.example.administrator.idemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.administrator.idemo.urls.GetConn;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity{
    EditText username;
    EditText password;
    Button bt;
    Map<String,String> map;
    final  static  String url="http://192.168.1.102:8088/androidtest/index.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        map=new HashMap<>();
        username= (EditText) findViewById(R.id.username);
        password= (EditText) findViewById(R.id.password);

        bt= (Button) findViewById(R.id.bt);
        bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                map.put("username",username.getText().toString());
                map.put("password",password.getText().toString());
                (new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        GetConn getConn=new GetConn(url,getApplicationContext(),map);
                  //      getConn.DoGet();
                        getConn.DoPost();
                    }
                }).start();

            }
        });

    }


}





