package com.example.administrator.homework1.mvp.model;

/**
 * Created by Administrator on 2016/5/27.
 */
public interface MvpModel  {
}
